function errorNameCheck(){
    var errorName = document.forms["nameCheck"]["Confirm Your Data"];

    if (errorName==""){
        alert("Invalid Input! Name Must be Filled!");
        return false;
    }
}